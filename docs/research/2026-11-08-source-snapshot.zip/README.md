# EE 5239：反射、重力與多粒子碰撞的可重現原型

這個專案實作主動反射、融合接觸、純重力及多粒子彈性碰撞，並提供 momentum SGD、Adam／AdamW 與外部介入控制。除了 **NumPy 合成函數**，已新增官方 NanoGPT 小模型的標準優化器及介入基準；真實地形碰撞版尚未接入神經網路。

## 開始使用

研究歷程與報告入口：[實驗總紀錄及轉向原因](docs/experiment_log.md)、[完整設定／原始檔案登錄](docs/experiment_registry.json)、[實驗清單 CSV](docs/experiment_inventory.csv)。後續每輪都需補上動機、固定協議、所有結果含失敗，以及改方向的依據。

目前的文獻整理：[有限成本介入與保護好解](docs/research/2026-11-08-intervention-literature.md)，含前人方法、適用限制及尚未執行的下一輪設計。

在專案資料夾執行：

```sh
python3 run_smoke.py
python3 -m pytest -q
```

需要 Python 3.10 以上、NumPy、Matplotlib；測試另需 pytest。若使用乾淨環境，可先建立虛擬環境，再安裝 `.[test]`。不需要 GPU。

可調整測試規模與物理參數：

```sh
python3 run_smoke.py --seeds 10 --steps 300 --h 0.05 --beta 0.995 --mixing 0.5 --gap 0.2 --vz -0.1 --output output/smoke
```

程式會輸出 `config.json`、`summary.json`、`runs.csv`、每條軌跡與碰撞事件，以及三張診斷圖。圖中的陰影是不同初始條件的四分位範圍，不是信賴區間。報告中的數字屬於未調參的小型測試，不能用來推定 NanoGPT 效果。

## 方法一：主動反射

實作位於 `src/collision_optim/active.py`。

1. 計算候選速度 `v_trial = beta*v - h*gradient_scale*g`。
2. 候選位置為 `y = x + h*v_trial`。固定 `h` 時，普通 momentum SGD 的等價學習率為 `gradient_scale*h**2`。
3. 計算方向餘弦 `c`，以及同一目標／資料實現下的配對變化 `d=(loss(y)-loss(x))/(1+abs(loss(x)))`。
4. 只有 `c > epsilon_c` 且 `d > epsilon_f` 連續成立 `patience` 次才介入。沒有違反或完成介入後，計數器歸零。
5. 反射只反轉梯度法向分量，保留切向分量。這是人為控制策略，不是物理接觸事件，也不保證反射後 loss 下降。

預設 `epsilon_c=0.1`、`epsilon_f=0.001`、`patience=3` 都是可調的實驗設定，尚未被驗證為最佳值。梯度或候選速度接近零時，略過方向判斷。

`ActiveConfig(adaptive=True)` 支援以配對診斷樣本的平均值與 `epsilon_f + kappa*SE` 比較。對固定、確定性的合成函數，抽樣 SE 為零，因此等同固定門檻。若傳入 `paired_sampler(x,y,rng)`，呼叫端必須確保一對 `(x,y)` 共用同一批資料與隨機實現；每對呼叫仍計入兩次值評估。這個介面目前只供診斷抽樣，並非完整的 PyTorch 隨機訓練介面。

### API 範例

安裝本機套件後，或設定 `PYTHONPATH=src`，可使用：

```python
from collision_optim import (
    ActiveConfig, ActiveReflection, CountedObjective, Quadratic, State, run,
)

method = ActiveReflection(ActiveConfig(h=0.05, beta=0.995))
result = run(method, CountedObjective(Quadratic()), State([1.0], [0.3]), steps=300)
print(result.best_x, result.best_value, result.stop_reason)
```

`MomentumRestart` 使用完全相同的判準，介入時清除繼承動量，重新使用梯度步；`MomentumSGD` 不做反射或重置。

## 方法二：平滑受力與表面接觸的融合模型

實作位於 `src/collision_optim/hybrid.py`。

狀態為 `q=(x,z)`、速度 `w=(v,vz)`，單位質量，固定可行域為 `z >= f(x)`。使用：

```text
U(x,z) = mixing*f(x) + (1-mixing)*z
F(x,z) = (-mixing*grad(f(x)), -(1-mixing))
H = 0.5*||w||^2 + U
```

在表面 `z=f(x)` 上，`U=f(x)`。高度和目標值的尺度在這個原型中以無因次方式統一；這是一個明確的建模選擇，改變目標或座標尺度會改變接觸幾何。

每個大步依序進行阻尼、力的速度更新，以及含碰撞事件的位移子步。水平方向的自由更新具有 momentum SGD 形式，但完整演算法含輔助高度與接觸映射，並非原生 momentum SGD。

反射只在粒子真正接觸表面並朝表面內部運動時發生。接觸點法線為 `n=(-grad(f(x_contact)),1)/sqrt(1+||grad(f(x_contact))||^2)`，速度更新為 `w_after=w_before-2*(w_before@n)*n`。接觸後會繼續完成剩餘時間，必要時在同一大步處理多次碰撞。不使用 loss 惡化或耐心次數來觸發碰撞。

```python
from collision_optim import (
    CountedObjective, HybridConfig, HybridContact, Quadratic, run,
)

oracle = CountedObjective(Quadratic())
method = HybridContact(HybridConfig(h=0.05, beta=0.995, mixing=0.5))
initial = method.initialize(oracle, [1.0], [0.3], gap=0.2, vz=-0.1)
result = run(method, oracle, initial, steps=300)
print(result.best_x, result.best_value, result.stop_reason)
```

### 接觸求解的支援範圍

目前支援 `Affine`、`Quadratic`、`TiltedDoubleWell`、`Rosenbrock`。它們提供沿位移直線的解析多項式，因此可以搜尋所有接觸根，避免「起終點都在表面上方、途中卻穿牆」的錯誤。`x` 可以是多維向量，不限一維。

**這個解析幾何介面不是可直接套到 NanoGPT 的黑箱接觸偵測器。** 自訂目標除了 `value(x)`、`gradient(x)`，還需提供 `path_coefficients(x,displacement)`。沒有此介面時程式會明確拒絕，不會用不可靠的步末判斷假裝精確接觸。

遇到需要持續接觸約束力的精確掠碰，或單步碰撞次數超限時，會回報 `ContactResolutionError`。這類狀態尚未加入完整的持續接觸求解器；程式不會偷偷把位置投影回牆面或刪掉速度。已完成的軌跡和停止原因會保留在報告中。

## 能量與成本如何記錄

兩個方法都把阻尼、瞬間介入的動能變化，以及剩餘積分誤差分開記錄。`energy_residual` 是診斷量，不會被用來修改速度以強行維持能量。

- 主動反射：記錄 `K + gradient_scale*f(x)`。
- 融合模型：記錄完整的 `K + mixing*f(x) + (1-mixing)*z`。
- 固定牆反射不保證粒子的動量守恆；牆面承擔反作用衝量。完全彈性時，反射瞬間動能守恆。
- `elastic_pair_collision` 提供等質量雙體的衝量映射，並有動量與動能守恆測試。早期單粒子比較隔離反射機制；新增的群體排程器與成對比較見後文。

`CountedObjective` 分別計算所有值評估、梯度評估和解析路徑查詢。診斷與接觸點驗證也計費。超過預算時保留最後完整狀態；未完成步驟已花費的評估仍包含在總數。

Smoke test 共用水平作用力、初始位置／速度、步長及阻尼，並加入 `momentum_extra_reserve` 控制組，把融合模型起始的垂直動能與表面上方高度儲能轉配給普通方法的水平動能。**這不代表兩種狀態空間和位能完全相同，也不是已證明的公平能量匹配。** 解析路徑成本另外列出，合成函數的時間不能直接外推到神經網路。

## 接下來的擴充邊界

新增的 NanoGPT 基準比較標準優化器及外部位移控制，沒有宣稱物理碰撞優於 AdamW。真實地形碰撞若要接入神經網路，仍需處理一般黑箱曲面的接觸定位、mini-batch 導致的表面變化，以及群體中的持續接觸與同時多點接觸。

## 高維診斷：100 到 100,000 維

```sh
python3 run_highdim.py --dimensions 100 1000 10000 100000 --seeds 3 --steps 500
```

預設輸出到 `output/highdim`，包含原雙井實驗的事件分析、設定、全部 240 次執行的摘要、每條壓縮純量軌跡，以及 `highdim_comparison.png`。這輪固定兩個方法的既有設定，沒有針對結果調參。

四種測試設定為：

1. 隱式旋轉、條件數 100 的二次函數，所有座標都參與。
2. 每個座標都有一個傾斜雙井的可分離控制組。
3. 同樣的雙井，加上相鄰座標耦合。
4. 有鏈狀耦合與彎曲谷地的 Rosenbrock 目標。

非線性目標使用 `r=sqrt(d)*Q*x` 並平均局部能量，讓函數值、梯度與局部曲率的主要尺度在不同維度大致可比。`Q` 以三個 Householder 反射隱式表示；不建立 `d*d` 矩陣。旋轉本身不會讓旋轉等變的演算法變強或變弱，真正的交互作用來自雙井相鄰耦合及 Rosenbrock 鏈。

初始水平速度的總動能固定，不隨維度線性增加。方法間使用相同初始位置及水平速度；額外能量控制組另外列出。每次執行使用相同的函數／梯度呼叫上限，接觸定位的解析路徑查詢仍分開計數。此輪依然是單粒子反射測試，不能替代多粒子動量交換實驗。

比較指標為 `(best_f-known_minimum)/(initial_f-known_minimum)`，越小越好。雙井的成功標準另外要求至少 90% 的井座標落入較低的負向井，且相對差距不大於 0.1。這個標準和一維測試不同，不能直接比較兩輪成功次數。

`run(..., store_states=False)` 僅保存每步純量診斷，不保留每個時間點的十萬維向量；最後狀態與最佳參數仍在回傳值中。這避免軌跡記憶體隨 `steps*d` 成長。計算主體、曲面多項式與旋轉均採 O(d) 的結構化運算。只有三組種子，圖中四分位範圍不是統計信賴區間。

數值溢位會記為 `numerical_error`，保留最後完整狀態和實際已用成本，不會讓整批停止，也不會把發散當成有效收斂。摘要分開列出接觸失敗與數值失敗，最終差距的中位數排除失敗執行；圖中的失敗方法使用虛線並標註失敗數。

長批次每次執行後寫入 `checkpoint.json`。如果只是執行中斷、程式和設定沒有改變，可用相同指令加上 `--resume` 沿用已保存結果。設定不一致時會拒絕續跑；修改演算法程式後應使用新的輸出資料夾，不應以此功能混合不同版本。

### 數值穩定性診斷

```sh
python3 run_stability.py --dimension 100000 --duration 25 --h-values 0.05 0.025 0.0125
```

此測試針對十萬維 Rosenbrock，固定物理時間及連續阻尼率。較小步長會使用更多步數及評估，因此這不是等計算成本的優化器排名。主動版同時依步長調整耐心次數與 loss 變化門檻，以維持近似相同的觀察時間及變化率容忍度。設定、停止原因、評估次數與能量曲線會保存在 `output/stability`。

## 方法三：純重力、彈性碰撞與持續接觸

```sh
python3 run_gravity.py
python3 run_gravity_duration.py
```

`GravityContact` 位於 `src/collision_optim/gravity.py`。質量為 1，地形為 `z >= height_scale*f(x)`，只有垂直重力，位能為 `gravity*z`。預設 `gravity=0.5`、`height_scale=1`，因此表面上的位能係數與普通動量控制組的 `0.5*f` 相同。這個模型沒有另加水平梯度力，也沒有 loss 惡化觸發器。

自由飛行沿精確的拋體軌跡定位彈性碰撞，碰撞後繼續剩餘時間；表面上的零法向速度狀態則使用法向支撐力，沿曲面積分滑動。支撐力需要變負時離地。曲率由解析路徑的方向二階導數取得，沒有密集 Hessian。滑動採 RK4、步長加倍誤差估計與能量誤差檢查，不能據此宣稱整段模擬精確守恆或具有辛結構。

每個觀察大步開始施加一次速度阻尼，其動能改變獨立記錄；空中重力做功是 `gravity*(z_before-z_after)`。表面座標直接滿足接觸約束；進入此模式時若有浮點級別的約束修正，會另記 `constraint_correction_energy`，也包含在總能量殘差中。沒有以速度縮放補平能量。

```python
from collision_optim import CountedObjective, GravityConfig, GravityContact, Quadratic, run

method = GravityContact(GravityConfig(h=0.025, gravity=0.5))
oracle = CountedObjective(Quadratic())
initial = method.initialize(oracle, [1.0], [0.2], gap=0, on_surface=True)
result = run(method, oracle, initial, 500)
print(result.best_value, result.stop_reason)
```

`run_gravity.py` 預設比較 2、1,000、100,000 維，各三個種子與三種地形，並分為空中落下、表面切向出發兩組，合計 270 次優化執行。所有方法有相同時間與各類評估上限，但實際成本及走過的物理時間可能不同。表面組固定總初始動能；另外的 `momentum_energy_match` 控制與純重力版有相同初始總機械能及相同表面位能係數。這仍不代表兩個狀態空間與運動幾何等價。前一版融合模型的表面位能為 `f`，有效障壁不同，報告保留這個限制。

輸出位於 `output/gravity`，包含純量軌跡、碰撞事件、物理守恆檢查、完整成本與四張比較圖。`airborne__time.png`、`surface__time.png` 使用物理時間；`airborne__gradients.png`、`surface__gradients.png` 使用梯度次數。解析路徑與值查詢另行記錄，不能把梯度次數直接當成總成本。圖中不同方法可因預算在不同時間停止。

持續接觸可能很快用完梯度預算。`run_gravity_duration.py` 因此另做二維與十萬維耦合雙井的固定時間診斷：seed 0、相同初始機械能、時間 25，不設評估上限，成本完整保存於 `output/gravity_duration`。這組只檢查讓模型走足時間後的行為，不是等成本的排名。模型與驗證設計見 `docs/gravity_design.md`。

本輪已完成的結果與限制見 [純重力實驗報告](docs/gravity_results.md)。

## 多粒子：共用時鐘的彈性碰撞

```sh
python3 run_population.py
python3 run_population_cost.py
python3 run_population.py --output output/population_preflight --seeds 2 --steps 60 --geometry-seeds 5
```

`src/collision_optim/population.py` 新增 `PopulationState`、`PopulationConfig`、`PopulationGravity`、`PopulationOracle` 與 `run_population`。各粒子維持原本的純重力自由飛行與地形反彈，所有粒子共用事件時鐘與阻尼時刻。粒子間距離首次達到固定 `rho` 且正在靠近時，沿接觸點中心連線施加等質量彈性衝量；不以 loss 或梯度判斷是否碰撞。

空中各粒子的重力加速度相同，相對位置為直線，因此可解析求出二體接觸時間。每次先推進至最近的地形或粒子間接觸，再重新預測。這避免分別跑完一步後才發現中途已穿過另一粒子。粒子中心受地形限制，`rho` 是模型的相互排斥距離，未額外模擬實體球半徑造成的地形偏移。

此版本是**孤立二體衝量的群體原型**。共享粒子的同時多點接觸、需要持續支撐力的貼面狀態，以及二體碰撞需要地形同時提供衝量時，都會明確停止。既有單粒子持續接觸方法沒有刪除，但尚未與此群體排程器聯立。失敗不以投影位置或任意交換順序掩蓋。

預設用二維參數地形（另加高度），比較 4 個獨立粒子與 4 個可碰撞粒子。接觸距離 0.12／0.24、三種地形、各 20 個種子，共 180 條軌跡及 120 組成對比較；每個種子的獨立基線由兩個接觸距離共用。初始位置、速度、總動能 0.6、總機械能與評估上限完全配對。

每個群體共用 10,000 次總 oracle 呼叫上限，值、梯度與解析路徑每次各記一個呼叫，同時分別列出其數量。這是評估記帳規則，並不假定三種操作實際成本相同；粒子對預測檢查與實際耗時另外記錄。結果按共同觀察網格評分；傾斜雙井的已知分界線穿越時間則沿自由飛行解析記錄，與低 loss 目標到達時間分開。

`run_population_cost.py` 再將已保存軌跡切齊至共同評估上限 `3*N*steps`，預設為 6,000 次。此上限由設定與每步最小查詢量決定，不依 loss 選擇；只採用上限內最後完整觀察點，不插值或外推。這讓「固定運動時間」與「相同評估上限」的結果分開查看，完整原始軌跡不會改動。

`output/population` 保存設定、初態、完整軌跡、逐次碰撞、成對改善／惡化／未完成數、守恆及穿透檢查。受控的斜向能量集中與障壁轉移案例另存為 `mechanisms.json`，不混入隨機初態成效統計。另有固定初始雲團大小、總動能與觀察時間的 2／10／100／1,000 維相遇頻率診斷；這是幾何可行性測試，未宣稱已完成高維優化。

設計與驗證範圍見 [多粒子設計](docs/superpowers/specs/2026-11-05-population-collisions-design.md)，已完成結果見 [多粒子實驗報告](docs/population_results.md)。

## 停滯時發球：有限供能與直接擾動對照

```sh
python3 run_strategic.py
python3 run_strategic.py --output output/strategic_check --seeds 2 --steps 100
```

`src/collision_optim/strategic.py` 在純重力群體原型上加入 `StrategicConfig`、`StagnationMonitor`、`run_strategic`。這輪以一個目標粒子出發，最多新增兩個輔助球；**只評分原目標，輔助球不算額外搜尋者**。這是純重力模型的介入策略，尚未接到 momentum SGD 或 NanoGPT。

每個物理時間 1 的視窗同時檢查：最佳 loss 的相對進展不大於 `1e-4`、平均水平動能不大於 `0.002`、正規化路徑活動不大於 `0.05`。連續兩個視窗成立才允許介入，成功後冷卻 4 個時間單位。這個判準偵測低水平動能的停滯，不能判斷是否已到好解，也不以短暫上坡觸發反射。

比較四組：繼續原運動、直接隨機水平速度擾動、沿可行發球方向的直接擾動，以及真實輔助球。三個介入組均為單次供能 `0.20`、最多兩次、總供能上限 `0.40`，但軌跡改變後的觸發時間與實際花費可能不同。方向配對組與發球組在首次可行介入前使用相同的幾何規劃；直接隨機擾動省去這些查詢。

新球總能量包含動能與 `gravity*z`，位能零點固定為 `z=0`。發球規劃會計入隨後的共同阻尼，讓兩球先飛行約 `0.025` 時間單位再真實接觸；不可行方向放棄，失敗規劃仍計費。新增球會一直保留。**停滯觸發的是發球，反彈仍由接觸產生。**

全系統帳本分開記錄外部帶入的能量／動量、阻尼、重力與地形衝量；另記目標粒子得到的二體能量轉移與重力做功。新增質量使供能帳本依賴固定的位能參考，這個原型尚未具備對 loss 垂直平移的不變性。

預設三種二維情境、各 20 個種子與四組策略，共 240 條軌跡，時間上限 25，整個群體共用 12,000 次 oracle 呼叫上限。壞井初始能量低於障壁；好井與二次函數用來檢查不必要的介入。已知極小值只用於初態與評分，沒有提供給發球方向或停滯偵測器。另按事先固定的 `3*steps` 呼叫上限比較，預設 1,500，只採上限內最後一筆已提交紀錄，不插值或外推。

`output/strategic` 保存設定與程式雜湊、共用初態、逐步壓縮軌跡、偵測紀錄、介入與碰撞事件、固定時間／固定成本的配對摘要，以及兩張圖。既有輸出資料夾禁止覆寫；重跑請指定新的 `--output`。群體持續接觸與共享多點接觸仍未聯立求解。設計見 [停滯發球設計](docs/superpowers/specs/2026-11-05-strategic-launch-design.md)，結果見 [停滯發球實驗報告](docs/strategic_results.md)。

## 預演後才發球：規劃成本與首次衝量控制

```sh
python3 run_predictive.py
python3 run_predictive.py --output output/predictive_budget1500_new --oracle-budget 1500
python3 run_predictive.py --output output/predictive_check --seed-start 90 --seeds 2 --steps 220
```

`src/collision_optim/predictive.py` 負責共用查詢帳本與有限預演，`predictive_runner.py` 負責真實執行及物理帳本。原本的停滯條件只允許規劃；先預演不介入，再測兩個相反方向與由小至大的 `0.10 / 0.20 / 0.30` 供能，每個分支觀察時間固定為 8。只有相對於不介入的原目標最佳 loss 改善超過 `1e-4`，才選該層較好的可行方案；優先採用最低通過的供能層。

四組為繼續運動、廉價隨機速度擾動、預演後在預定接觸時刻施加相同首次衝量，以及預演後真正發球。直接衝量只匹配首次接觸對原目標的衝量和時刻，沒有保留輔助球；其供能記為實際外部做功。兩組仍會因後續互動與剩餘能量不同而產生不同決策。

所有預演都使用同一個已計費 oracle。分支中的低 loss 不會算成真實解，虛擬球也不加入真實供能。規劃額度不足則拒絕，不提交部分分支。介入後至少觀察完整預演時間，沒有改善時延長冷卻；不倒帶或刪除真實小球。

預設三種情境（壞井、好井、精確鞍點），主測試使用 seed 100–119，共 240 條，固定時間上限 25、總查詢上限 24,000；每條最多兩次規劃、18,000 次規劃查詢。另把高預算軌跡在 1,500 次處截取。因為政策會看剩餘預算，**另外直接給總上限 1,500 跑同樣 240 條**，保存在 `output/predictive_budget1500`，與高預算前綴分開解讀。

`output/predictive` 保存全部決策、逐分支的原目標預演軌跡、真實軌跡、碰撞與衝量、分項成本、來源雜湊及圖形。已有輸出禁止覆寫。這是確定性合成地形的診斷版，尚未代表可用於黑箱神經網路；精確鞍點案例特意保留不介入時的對稱性。設計見 [預演介入設計](docs/superpowers/specs/2026-11-06-predictive-intervention-design.md)，結果見 [預演介入實驗報告](docs/predictive_results.md)。

## 標準優化器、介入控制與小型 NanoGPT

```sh
python3 run_optimizer_comparison.py
python3 run_nanogpt_comparison.py
python3 audit_optimizer_comparison.py synthetic output/optimizer_comparison
python3 audit_optimizer_comparison.py nanogpt output/nanogpt_comparison --matched-replay
python3 plot_optimizer_comparison.py
```

合成函數仍只需原本依賴；NanoGPT 另需 PyTorch，可安裝 `.[test,benchmark]`。本輪以已安裝的 PyTorch 2.11.0、CPU float32 執行。`third_party/nanogpt/model.py` 是固定提交的未改動官方版本，保留 MIT 授權；文字資料位於 `data/tinyshakespeare.txt`，來源與雜湊均保存。沒有下載預訓練權重。

`optimizer_controls.py` 實作標準 Momentum、Adam 與 AdamW 更新，逐步與 PyTorch 核對，包括非零 weight decay。外部介入使用獨立衰減速度 q；在 Momentum 上可等價為原動量脈衝，在 Adam 上保留 m、v、step 不直接修改，明確視為額外探索控制，沒有 Adam 能量守恆宣稱。零 weight decay 的 Adam／AdamW 身分關係有獨立測試。

`output/optimizer_comparison` 有六種地形、獨立調參種子、每個基底四組設定，介入組繼承選定的基底設定。正式 seed 200–209，共八種方法。主比較 480 條都使用實際總上限 1,500 次查詢；另有 480 條固定最多 500 個實際更新的高預算診斷，後者不是等成本排名。值、梯度及解析路徑分項計費；物理模型的初始高度／垂直儲能另列，不宣稱與 Adam 等初始機械能。

`output/nanogpt_comparison` 使用 108,352 參數的小型字元模型。文字依順序分成 train／tuning／test，比例 80／10／10；每個基底九個設定，以 tuning split 選擇，三個正式種子的 test split 只於最後評估。每組相同 1,200 個 batch-forward 等價單位，完整訓練更新計 3、無梯度 probe 計 1；這是明列的計算近似，另報實際步數與耗時。預演只讀 train，完整複製模型及 optimizer state，額外運算計費。

本輪神經網路介入沒有觸發。診斷使實際更新從 400 降為 386；以原版只跑 386 次的額外核對，得到完全相同權重，避免把較短訓練誤認為介入效果。這項重放只作因果核對，不用來重選設定或 checkpoint。

設計見 [標準優化器比較設計](docs/superpowers/specs/2026-11-06-standard-optimizer-comparison-design.md)，全部結果與限制見 [標準優化器及 NanoGPT 比較報告](docs/optimizer_comparison_results.md)。重跑須指定新的 `--output`，既有資料禁止覆寫。

## 便宜的動量控制：繼續、減速與有限加能

```sh
PYTHONPATH=src python3 run_momentum_routing.py --suite synthetic --output output/momentum_routing_new
PYTHONPATH=src python3 run_momentum_routing.py --suite nanogpt --output output/nanogpt_routing_new
python3 audit_momentum_routing.py synthetic output/momentum_routing_new
python3 audit_momentum_routing.py nanogpt output/nanogpt_routing_new
```

`momentum_routing.py` 只讀已有的 loss、梯度、動量與位移，選擇繼續、減速或有限脈衝；沒有模型預演或額外診斷前向。`nanogpt_routing.py` 在原生 SGD 動量上實作，減速同時修改原生 buffer 與外部速度。脈衝後保留兩個視窗的探索觀察期，容許短暫上坡。這些是控制動作，沒有冒稱自然碰撞。

本輪正式完成 360 次合成與 18 次 NanoGPT；新增 22 個機制測試後，全套 **189 passed**。每條合成軌跡精確使用 1,500 次查詢，每組 NanoGPT 都完成 400 次更新。供能、耗散、梯度做功與離散誤差分開記錄，不以帳本閉合宣稱全程守恆。

結果顯示低成本停滯判斷仍會誤傷好解：加能讓精確鞍點成功 10/10，卻讓好井最後達標由原版 10/10 降到 4/10。NanoGPT 自適應版平均 loss 為 2.56617，原版 Momentum 2.56932，AdamW 2.50131；三個配對只有一個改善，而且加能沒有觸發，自適應與單純減速的權重完全相同。沒有額外模型前向仍有向量診斷耗時，尚未建立效率或穩定優勢。

完整流程、限制與結果見 [動量控制實驗報告](docs/momentum_routing_results.md)，預先固定的規則見 [實驗設計](docs/superpowers/specs/2026-11-06-momentum-routing-design.md)。原始資料在 `output/momentum_routing`、`output/nanogpt_routing`；`plot_momentum_routing.py` 可重建圖形。

## 減速分支：十個新種子的重複驗證

```sh
PYTHONPATH=src python3 run_damping_replication.py --output output/damping_replication_new
PYTHONPATH=src python3 run_damping_replication.py --audit --output output/damping_replication_new
python3 audit_damping_prefixes.py output/damping_replication_new
```

新增固定時刻減速對照：在完成 80／160／240／320 次更新後，將原生動量減半，不做逐步狀態診斷。與原版 Momentum、依狀態重置、依狀態減速及 AdamW，在種子 400–409 上共完成 **50 次訓練**；每組 400 次實際更新，沒有加能或額外模型查詢。全套 **193 個測試通過**。

十個新種子未支持原本的微小平均收益：原版 Momentum 平均 test loss **2.54697**，依狀態減速 **2.54824**，固定減速 **2.54683**，AdamW **2.49770**。依狀態減速相對原版與固定減速，都是 5 個改善、5 個惡化，兩個配對 bootstrap 區間都跨零。目前不把該判準作為已建立的性能優勢。

完整結果、成本與物理／動量係數的關係見 [減速重複驗證報告](docs/damping_replication_results.md)，規則見 [固定設計](docs/superpowers/specs/2026-11-06-damping-replication-design.md)。資料與圖形在 `output/damping_replication`；`plot_damping_replication.py` 可重建圖形。

## 參考

- [Adaptive Restart for Accelerated Gradient Schemes](https://arxiv.org/abs/1204.3982)
- [Reflection, Refraction, and Hamiltonian Monte Carlo](https://proceedings.neurips.cc/paper_files/paper/2015/hash/8303a79b1e19a194f1875981be5bdb6f-Abstract.html)
- [LAMMPS 反射壁與數值誤差說明](https://docs.lammps.org/fix_wall_reflect.html)
- [Neighbor List Collision-Driven Molecular Dynamics Simulation](https://math.nyu.edu/inmemoriam/donev/Packing/EDMD.pdf)

